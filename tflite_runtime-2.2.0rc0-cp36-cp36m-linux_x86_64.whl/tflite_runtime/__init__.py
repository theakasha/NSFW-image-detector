__version__ = '2.2.0rc0'
__git_version__ = '0.6.0-80219-g3c1e8c0341'
